package com.borisov.orm.service;

import com.borisov.orm.model.Contact;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface ContactService {

    List<Contact> allContacts();

    @Transactional
    List<Contact> allContacts(int id);

    void add(Contact contact);
    void delete(Contact contact);
    void edit(Contact contact);
    Contact getById(int id);
}
