package com.borisov.orm.service;

import com.borisov.orm.dao.ContactDAO;
import com.borisov.orm.model.Contact;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import java.util.List;

@Service
public class ContactServiceImpl implements ContactService {

    private ContactDAO contactDAO;

    @Autowired
    public void setContactDAO(ContactDAO filmDAO) {
        this.contactDAO = contactDAO;
    }

    @Override
    public List<Contact> allContacts() {
        return null;
    }

    @Override
    @Transactional
    public List<Contact> allContacts(int id) {
        return contactDAO.allContacts();
    }

    @Override
    @Transactional
    public void add(Contact contact) {
        contactDAO.add(contact);
    }

    @Override
    @Transactional
    public void delete(Contact contact) {
        contactDAO.delete(contact);
    }

    @Override
    @Transactional
    public void edit(Contact contact) {
        contactDAO.edit(contact);
    }

    @Override
    @Transactional
    public Contact getById(int id) {
        return contactDAO.getById(id);
    }
}