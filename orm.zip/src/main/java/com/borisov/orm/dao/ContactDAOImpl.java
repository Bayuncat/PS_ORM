package com.borisov.orm.dao;

import com.borisov.orm.model.Contact;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
public class ContactDAOImpl implements ContactDAO {
    private static final AtomicInteger AUTO_ID = new AtomicInteger(0);
    private static Map<Integer, Contact> contacts = new HashMap<>();

    @Override
    public List<Contact> allContacts() {
        return new ArrayList<>(contacts.values());
    }

    @Override
    public void add(Contact contact) {
        contact.setId(AUTO_ID.getAndIncrement());
        contacts.put(contact.getId(), contact);
    }

    @Override
    public void delete(Contact contact) {
        contacts.remove(contact.getId());
    }

    @Override
    public void edit(Contact contact) {
        contacts.put(contact.getId(), contact);
    }

    @Override
    public Contact getById(int id) {
        return contacts.get(id);
    }
}