package com.borisov.orm.dao;

import com.borisov.orm.model.Contact;

import java.util.List;

public interface ContactDAO {

    List<Contact> allContacts();
    void add(Contact contact);
    void delete(Contact contact);
    void edit(Contact contact);
    Contact getById(int id);
}
